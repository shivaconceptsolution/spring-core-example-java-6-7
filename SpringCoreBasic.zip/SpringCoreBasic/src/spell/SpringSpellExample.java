package spell;

import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class SpringSpellExample {

	public static void main(String[] args) {
		ExpressionParser parser = new SpelExpressionParser();
		System.out.println(parser.parseExpression("10+2").getValue());
		System.out.println(parser.parseExpression("'Welcome SPEL'+'!'").getValue());
		System.out.println(parser.parseExpression("'Today is: '+ new java.util.Date()").getValue());
		System.out.println(parser.parseExpression("'sonoo'.length()==5").getValue());  
	}

}
