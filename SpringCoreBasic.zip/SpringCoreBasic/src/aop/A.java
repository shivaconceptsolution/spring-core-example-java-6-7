package aop;

public class A {
    public void fun()
    {
    	System.out.println("Interceptor Class");
    }
}
