package scs;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class AccessSI {

	public static void main(String[] args) {
		Resource res = new ClassPathResource("siContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		SI s =(SI) factory.getBean("sibean");
	    SIBusiness obj = new SIBusiness();
	    obj.calcSi(s);

	}

}
