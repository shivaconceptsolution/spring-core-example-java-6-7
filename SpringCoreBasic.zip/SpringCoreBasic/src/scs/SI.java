package scs;

public class SI {
	float p,r,t;
	public SI(float p, float r, float t)
	{
		this.p=p;
		this.r=r;
		this.t=t;
	}
	

}
