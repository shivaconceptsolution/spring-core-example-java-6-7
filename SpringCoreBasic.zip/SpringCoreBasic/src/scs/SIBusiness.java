package scs;

public class SIBusiness {
	
	public void calcSi(SI obj)
	{
		System.out.println("Result is "+(obj.p*obj.r*obj.t)/100);
	}
}
