package ci;

import java.util.Map;
import java.util.Set;

public class Emp {
String empname;
Map mp;
Emp(String empname,Map mp)
{
	this.empname = empname;
	this.mp = mp;
}

public void displayEmp()
{
	System.out.println("Empname is "+empname);
	Set<Map.Entry<String,String>> se = mp.entrySet();
	for(Map.Entry<String,String> s : se)
	{
		System.out.println(s.getKey() + " "+s.getValue());
	}
	
}
}
