package factorymethod;

public class Addition {
	private static final Addition obj=new Addition();
	 public Addition getAddition()
	    {
	           System.out.println("factory method ");
	           return obj;
	    }  public void msg()
	    {
	           System.out.println();
	    }
}
