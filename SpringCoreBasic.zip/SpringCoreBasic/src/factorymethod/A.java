package factorymethod;

public class A {
	private static final A obj=new A();
	static float p,r,t,si;
    private A()
    {
        System.out.println("SI Program");
        p=52000;
        r=2;
        t=2;
        		
    }
    public A getA()
    {
          
           return obj;
    }

    public void calcSi()
    {
           System.out.println((p*r*t)/100);
    }
}
