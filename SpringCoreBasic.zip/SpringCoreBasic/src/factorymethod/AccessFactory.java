package factorymethod;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AccessFactory {
public static void main(String args[])
{
	ApplicationContext context=new ClassPathXmlApplicationContext("factorycontext.xml");
    A a=(A)context.getBean("a");
    a.calcSi();
}
}
